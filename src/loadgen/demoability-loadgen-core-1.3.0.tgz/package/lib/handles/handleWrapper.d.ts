import { ElementHandle } from "puppeteer";
import { IHandleWrapper } from "./types";
/**
 * Wrapps Puppeteer Element Handle,
 * allows for defining another handle as a root
 */
export declare class HandleWrapper implements IHandleWrapper {
    readonly handle: ElementHandle;
    readonly selectorString: string;
    readonly root?: IHandleWrapper;
    constructor(handle: ElementHandle, selectorString: string, root?: IHandleWrapper);
    getHandle(): ElementHandle;
    toString(): string;
    static fromHandle(handle: ElementHandle<Node>, selectorString: string, root?: IHandleWrapper): IHandleWrapper;
}
//# sourceMappingURL=handleWrapper.d.ts.map