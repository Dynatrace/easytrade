export { IHandleWrapper } from "./types";
export { HandleWrapper } from "./handleWrapper";
//# sourceMappingURL=index.d.ts.map