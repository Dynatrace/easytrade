import { ElementHandle } from "puppeteer";
/**
 * Wrapper for a Pupeteer ElementHandle
 */
export interface IHandleWrapper {
    /**
     * Returns the underlying pupeteer ElementHandle
     *
     */
    getHandle(): ElementHandle;
    /**
     * Return a string representation of the handle
     */
    toString(): string;
}
//# sourceMappingURL=types.d.ts.map