import { ClickOptions, EvaluateFunc, Page } from "puppeteer";
import { IPageActions, PageActionsConfig } from "./types";
import { Logger } from "winston";
import { ISelector } from "../selectors";
import { IHandleWrapper } from "../handles";
/**
 * The PageActions class provides helper methods for handling web pages.
 */
export declare class PageActions implements IPageActions {
    readonly page: Page;
    readonly logger: Logger;
    readonly config: PageActionsConfig;
    /**
     * @param page A web page where the actions are to be made.
     * @param logger Specified logger.
     * @param config Offers to change default configuration of delay variants, optional.
     */
    constructor(page: Page, logger: Logger, config: PageActionsConfig);
    setupPage(setup: (page: Page) => Promise<void>): Promise<void>;
    isSelectorPresent(selector: ISelector): Promise<boolean>;
    getHandle(selector: ISelector): Promise<IHandleWrapper>;
    getAllHandles(selector: ISelector): Promise<IHandleWrapper[]>;
    scrollIntoView(handleWrapper: IHandleWrapper, waitInterval?: number): Promise<void>;
    clickHandle(handleWrapper: IHandleWrapper, options?: ClickOptions): Promise<void>;
    click(selector: ISelector): Promise<void>;
    inputHandle(handle: IHandleWrapper, value: string): Promise<void>;
    clearInput(handle: IHandleWrapper): Promise<void>;
    input(selector: ISelector, value: string): Promise<void>;
    navigateHandle(handle: IHandleWrapper): Promise<void>;
    navigate(selector: ISelector): Promise<void>;
    selectOptionHandle(handle: IHandleWrapper, option: string): Promise<void>;
    selectOption(selector: ISelector, option: string): Promise<void>;
    sleep(milliseconds: number, noiseProportion?: number): Promise<void>;
    getProperty<Type = unknown>(selector: ISelector, propertyName: string): Promise<Type>;
    getPropertyHandle<T = unknown>(handle: IHandleWrapper, propertyName: string): Promise<T>;
    endDtSession(): Promise<void>;
    evaluate(func: string | EvaluateFunc<unknown[]>, ...args: unknown[]): Promise<unknown>;
    getInnerText(selector: ISelector): Promise<string>;
    gotoPage(url: string): Promise<void>;
    standardDelay(): Promise<void>;
    shortDelay(): Promise<void>;
    longDelay(): Promise<void>;
}
//# sourceMappingURL=pageActions.d.ts.map