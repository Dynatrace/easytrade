import { PageActionsConfig } from "./types";
/**
 * Return validated and complete config for PageActions
 * @param config Optional config which can be used to override defaults
 * @returns
 */
export declare function defineConfig(config?: Partial<PageActionsConfig>): PageActionsConfig;
export declare function validateConfig(config: PageActionsConfig): void;
//# sourceMappingURL=config.d.ts.map