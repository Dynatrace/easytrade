import { ClickOptions, EvaluateFunc, Page } from "puppeteer";
import { IHandleWrapper } from "../handles";
import { ISelector } from "../selectors";
export type PageActionsConfig = {
    shortDelayMs: number;
    shortDelayNoise: number;
    standDelayMs: number;
    standDelayNoise: number;
    longDelayMs: number;
    longDelayNoise: number;
    endDtSessionTimeout: number;
    disableDelay: boolean;
};
export type PageSetup = (page: Page) => Promise<void>;
export interface IPageActions {
    /**
     * Allows for additional page setup
     *
     * @param setup a function that will be called on the page
     */
    setupPage(setup: PageSetup): Promise<void>;
    /**
     * Checks if the element is present on a web page.
     *
     * @param selector A selected element on a web page.
     * @returns A Promise that resolves with true if the condition is met, false otherwise.
     */
    isSelectorPresent(selector: ISelector): Promise<boolean>;
    /**
     * Provides handle to the selected element on a web page.
     *
     * @param selector A selected element on a web page.
     * @returns A Promise that resolves with HandleWrapper to selected elements.
     */
    getHandle(selector: ISelector): Promise<IHandleWrapper>;
    /**
     * Provides handles for all elements selected by the given selector on a web page. Function does not perform any waiting for the elements to appear.
     *
     * @param selector A selected element on a web page.
     * @returns A Promise that resolves with an array of IHandleWrappers for selected elements, the array may be empty if no element is found.
     */
    getAllHandles(selector: ISelector): Promise<IHandleWrapper[]>;
    /**
     * Locates the element associated with the specified handler, scrolls to the view if needed.
     *
     * @param handleWrapper The handle object to the element to be located.
     * @param waitInterval Specifies the time in milliseconds to wait for an item to be located.
     */
    scrollIntoView(handleWrapper: IHandleWrapper, waitInterval?: number): Promise<void>;
    /**
     * Locates and clicks the element associated with the specified handler.
     *
     * @param handleWrapper The handle object to the element to be clicked.
     * @param options Click options.
     */
    clickHandle(handleWrapper: IHandleWrapper, options?: ClickOptions): Promise<void>;
    /**
     * Clicks the element associated with the specified selector.
     *
     * @param selector A selected element on a web page.
     */
    click(selector: ISelector): Promise<void>;
    /**
     * Locates and clear the input and insert value with the specified data.
     *
     * @param handle The handle object to the input element.
     * @param value A Value to be inserted into the input element.
     */
    inputHandle(handle: IHandleWrapper, value: string): Promise<void>;
    /**
     * Clears the input element.
     *
     * @param handle The handle object to the input element.
     */
    clearInput(handle: IHandleWrapper): Promise<void>;
    /**
     * Gets handle to the input element and insert value with the specified data.
     *
     * @param selector A selected element on a web page.
     * @param value Value to be inserted into the input element.
     */
    input(selector: ISelector, value: string): Promise<void>;
    /**
     * Navigates to the element assiociated with the specified handle, reloads and waits for the page if necessary.
     *
     * @param handle The handle object to the input element.
     */
    navigateHandle(handle: IHandleWrapper): Promise<void>;
    /**
     * Navigates to the element with the specified selector, reloads and waits for the page if necessary.
     *
     * @param selector A selected element on a web page.
     */
    navigate(selector: ISelector): Promise<void>;
    /**
     * Selects handle for the element with the specified option.
     *
     * @param handle Handle to the element for selecting options.
     * @param option Specified option to be selected.
     */
    selectOptionHandle(handle: IHandleWrapper, option: string): Promise<void>;
    /**
     * Selects the specified option in the element assiosiated with the specified selector.
     *
     * @param selector A selected element on a web page.
     * @param option Specified option to be selected.
     */
    selectOption(selector: ISelector, option: string): Promise<void>;
    /**
     * Generates delay of the specified size in miliseconds.
     *
     * @param milliseconds Specified delay in miliseconds.
     * @default milliseconds value from the delayConfig.
     * @param noiseProportion Specified noise proportion.
     * @default noiseProportion value from the delayConfig.
     */
    sleep(milliseconds: number, noiseProportion?: number): Promise<void>;
    /**
     * Gets specified property from the element within given selector.
     *
     * @param selector A selected element on a web page.
     * @param propertyName Property name.
     * @returns The response from getPropertyHandle method.
     */
    getProperty<Type = unknown>(selector: ISelector, propertyName: string): Promise<Type>;
    /**
     * Gets the specified property for the specified handle.
     *
     * @param handle The handle object to the input element.
     * @param propertyName Property name.
     * @returns A JSON representation of the property handle object.
     */
    getPropertyHandle<Type = unknown>(handle: IHandleWrapper, propertyName: string): Promise<Type>;
    /**
     * Ends dynatrace session using data from agent.
     */
    endDtSession(): Promise<void>;
    /**
     * Evaluates provided function within page.
     *
     * @param func Function to be executed.
     * @param args Arguments to be passed to the function.
     * @returns A Promise that resolves with value of the evaluated function.
     */
    evaluate(func: string | EvaluateFunc<unknown[]>, ...args: unknown[]): Promise<unknown>;
    /**
     * Gives the text value of the element with the specified selector.
     *
     * @param selector A selected element on a web page.
     * @returns A Promise that resolves with value of the selected element.
     */
    getInnerText(selector: ISelector): Promise<string>;
    /**
     * Navigates to a specified URL in a browser.
     *
     * @param url The URL of the page that will be opened in the browser.
     */
    gotoPage(url: string): Promise<void>;
    standardDelay(): Promise<void>;
    shortDelay(): Promise<void>;
    longDelay(): Promise<void>;
}
//# sourceMappingURL=types.d.ts.map