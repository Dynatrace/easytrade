export { IPageActions, PageActionsConfig, PageSetup } from "./types";
export { PageActions } from "./pageActions";
export { defineConfig, validateConfig } from "./config";
//# sourceMappingURL=index.d.ts.map