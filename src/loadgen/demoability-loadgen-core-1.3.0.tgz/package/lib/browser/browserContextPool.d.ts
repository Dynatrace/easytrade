import { BrowserContext, LaunchOptions } from "puppeteer";
import { LoggerOptions } from "winston";
import { BrowserProvider, IBrowserContextPool } from "./types";
export declare class BrowserContextPool implements IBrowserContextPool {
    readonly browserCount: number;
    readonly browserTTLMs: number;
    readonly browserOptions: LaunchOptions;
    readonly name: string;
    readonly browserProvider: BrowserProvider;
    readonly loggerOptions: LoggerOptions;
    private isActive;
    private activeBrowsers;
    private inactiveBrowsers;
    private logger;
    constructor(name: string, browserOptions: LaunchOptions, browserCount: number, browserTTLMs: number, loggerOptions: LoggerOptions, browserProvider: BrowserProvider);
    getContext(): Promise<BrowserContext>;
    start(): Promise<void>;
    stop(): Promise<void>;
    runLoop(): Promise<void>;
    /**
     * Attempt to start new browsers, the browsers will be added to
     * the list of active browsers. If starting some of the browsers
     * will fail it will be reported but not retried. Because of that
     * there's no guarantee that running this function will actually
     * start any browsers
     *
     * @param count the amount of browsers that will be started
     */
    private startBrowsers;
    /**
     * Check all browsers in activeBrowsers list
     * and move those that are expired to inactiveBrowsers
     *
     * @param nowTimestamp if defined will be used as reference timestamp instead of Date.now()
     */
    private expireBrowsers;
    /**
     * Attempt to close inactiveBrowsers,
     * see closeInactiveBrowser for details
     *
     * @param nowTimestamp if defined will be used as reference timestamp instead of Date.now()
     */
    private closeInactiveBrowsers;
}
//# sourceMappingURL=browserContextPool.d.ts.map