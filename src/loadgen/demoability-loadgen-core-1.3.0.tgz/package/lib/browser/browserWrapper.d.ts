import { Browser, BrowserContext, LaunchOptions } from "puppeteer";
import { LoggerOptions } from "winston";
import { IBrowserWrapper } from "./types";
/**
 * Factory function that returns the browser wrapper
 *
 * @param browserOptions Puppeteer launch options that will be used when creating new browsers
 * @param loggerOptions options that will be used when creating the logger
 * @param expirationTimestamp timestamp after which the browser will expire and will be shut down
 * @returns
 */
export declare function createBrowserWrapper(browserOptions: LaunchOptions, loggerOptions: LoggerOptions, expirationTimestamp: number): Promise<BrowserWrapper>;
/**
 * Wrapper class for Browser object
 * that makes it easier to manage it
 * and track when it should be closed
 */
export declare class BrowserWrapper implements IBrowserWrapper {
    readonly browser: Browser;
    readonly expirationTimestamp: number;
    readonly browserPid: number;
    private logger;
    constructor(browser: Browser, browserPid: number, loggerOptions: LoggerOptions, expirationTimestamp: number);
    safeClose(hardTimeoutMs: number, nowTimestamp?: number): Promise<boolean>;
    getBrowserPid(): number;
    close(): Promise<void>;
    getContext(): Promise<BrowserContext>;
    getActiveContexts(): number;
    isExpired(nowTimestamp?: number): boolean;
}
//# sourceMappingURL=browserWrapper.d.ts.map