import { LaunchOptions, SupportedBrowser } from "puppeteer";
import { HeadlessType } from "./types";
export declare function createBrowserOptions(options?: {
    headless?: HeadlessType;
    product?: SupportedBrowser;
}): LaunchOptions;
//# sourceMappingURL=createBrowserOptions.d.ts.map