import { BrowserContext, LaunchOptions } from "puppeteer";
import { LoggerOptions } from "winston";
export interface IBrowserContextPool {
    /**
     * Initialize and start the context pool, after this function resolves
     * it should be safe to run getContext()
     */
    start(): Promise<void>;
    /**
     * Stop the pool and close all the underlying resources
     */
    stop(): Promise<void>;
    /**
     * Run the maintenance loop on the resources for as long
     * as the pool is active,
     */
    runLoop(): Promise<void>;
    /**
     * Get the BrowserContext from the pool, if the pool is not active
     * (before start() or after stop()) it may throw an error
     */
    getContext(): Promise<BrowserContext>;
}
export interface IBrowserWrapper {
    /**
     * Close the underlying browser
     */
    close(): Promise<void>;
    /**
     * Attempt to close the browser,
     * if there are still active contexts browser won't be closed
     * unless it has been expired for longer than hardTimeoutMs
     *
     * @param hardTimeoutMs the browser will be closed if expired for longer than this timeout
     * @param nowTimestamp if defined will be used as the reference timestamp instead of Date.now()
     * @returns true if the browser was closed
     */
    safeClose(hardTimeoutMs: number, nowTimestamp?: number): Promise<boolean>;
    /**
     * Return an incognito BrowserContext from the browser
     * @returns
     */
    getContext(): Promise<BrowserContext>;
    /**
     * Return the count of opened browser contexts
     * (excluding the default context,
     *  which is not given out by the wrapper)
     * @returns
     */
    getActiveContexts(): number;
    /**
     * Returns true if the browser is expired based on its TTL
     * @param nowTimestamp if defined will be used as the reference timestamp instead of Date.now()
     * @returns
     */
    isExpired(nowTimestamp?: number): boolean;
    /**
     * Return pid of underlying browser process
     */
    getBrowserPid(): number;
}
export type BrowserProvider = (browserOptions: LaunchOptions, loggerOptions: LoggerOptions, expirationTimestamp: number) => Promise<IBrowserWrapper>;
export type HeadlessType = boolean | "shell";
//# sourceMappingURL=types.d.ts.map