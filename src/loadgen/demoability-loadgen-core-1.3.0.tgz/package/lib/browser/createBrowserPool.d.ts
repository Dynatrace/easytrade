import { LaunchOptions } from "puppeteer";
import { LoggerOptions } from "winston";
import { BrowserProvider, IBrowserContextPool } from "./types";
type BrowserContextPoolOptions = {
    name: string;
    browserOptions: LaunchOptions;
    concurrentBrowsers: number;
    browserTimeToLiveMs: number;
    loggerOptions?: LoggerOptions;
    browserProvider?: BrowserProvider;
};
export declare function createBrowserContextPool(options: BrowserContextPoolOptions): IBrowserContextPool;
export {};
//# sourceMappingURL=createBrowserPool.d.ts.map