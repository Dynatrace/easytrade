export type TimeUnit = {
    msPerUnit: number;
    symbol: string;
};
export type Timeframe = {
    from: number;
    to: number;
};
export type Duration = {
    unit: TimeUnit;
    quantity: number;
};
export declare const TIME_UNITS: {
    readonly MILLISECOND: {
        readonly msPerUnit: 1;
        readonly symbol: "ms";
    };
    readonly SECOND: {
        readonly msPerUnit: 1000;
        readonly symbol: "s";
    };
    readonly MINUTE: {
        readonly msPerUnit: 60000;
        readonly symbol: "m";
    };
    readonly HOUR: {
        readonly msPerUnit: number;
        readonly symbol: "h";
    };
    readonly DAY: {
        readonly msPerUnit: number;
        readonly symbol: "d";
    };
};
//# sourceMappingURL=time.d.ts.map