/**
 * Adds noise with a percentage from to the specified base value. The noise is randomly generated from the <-noise,noise> range.
 *
 * @param baseValue A specified base value.
 * @param percentage A value from 0 and 1 representing percentage size for noise calculation.
 * @returns The value with noice.
 */
export declare function addNoise(baseValue: number, percentage: number): number;
export declare function randomBetween(a: number, b: number): number;
export declare function delay(timeoutMs: number): Promise<void>;
/**
 * Rotates the array by the number n (the array is mutated)
 * Positive numbers rotate right (move the end to the beginning)
 * Negative numbers rotate left (move the beginning to the end)
 *
 */
export declare function rotateArray(array: unknown[], n: number): void;
//# sourceMappingURL=utils.d.ts.map