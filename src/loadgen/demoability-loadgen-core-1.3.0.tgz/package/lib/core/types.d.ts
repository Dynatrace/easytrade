/**
 * Interface for LoadgenCore which is the central object in the library
 * it's used to start the visit generation
 */
export interface ILoadgenCore {
    /**
     * Entry method that starts the load generation
     * it will resolve when all of the visits has been ran
     */
    run(): Promise<void>;
}
//# sourceMappingURL=types.d.ts.map