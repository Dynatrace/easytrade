import { IBrowserContextPool } from "../browser";
import { ILoadgenCore } from "./types";
import { IWorker } from "../workers";
import { LoggerOptions } from "winston";
import { IProvider } from "../providers";
import { IVisit } from "../visits";
import { PageActionsConfig, PageSetup } from "../pageActions";
import { IStatsRunner } from "../stats";
/**
 * An implementation of LoadgenCore that uses single browser instance
 * with multiple contexts running visits concurrently
 */
export declare class ConcurrentContextsCore implements ILoadgenCore {
    readonly concurrency: number;
    readonly loggerOptions: LoggerOptions;
    readonly visitProvider: IProvider<IVisit>;
    readonly initialPageSetup?: PageSetup;
    readonly pageActionsConfig: PageActionsConfig;
    readonly contextPool: IBrowserContextPool;
    readonly statsRunner: IStatsRunner;
    private logger;
    constructor(concurrency: number, loggerOptions: LoggerOptions, visitProvider: IProvider<IVisit>, pageActionsConfig: PageActionsConfig, contextPool: IBrowserContextPool, statsRunner: IStatsRunner, initialPageSetup?: PageSetup);
    run(): Promise<void>;
    getWorkers(): IWorker[];
}
//# sourceMappingURL=concurrentContextsCore.d.ts.map