export declare class ConfigError extends Error {
}
//# sourceMappingURL=types.d.ts.map