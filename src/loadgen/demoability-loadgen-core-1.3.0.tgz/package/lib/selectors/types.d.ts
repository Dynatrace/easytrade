import { Page } from "puppeteer";
import { IHandleWrapper } from "../handles";
export interface ISelector {
    /**
     * Checks whether the selector is present on the specified web page.
     *
     * @param page A web page where the selected element should be located.
     * @returns A Promise that resolves with true if the condition is met, false otherwise.
     */
    isPresent(page: Page): Promise<boolean>;
    /**
     * Selects element identified by the selector on the specified web page.
     *
     * @param page A web page where the selected element should be located.
     * @returns A Promise that resolves with IHandleWrapper if the condition is met, null otherwise.
     */
    select(page: Page): Promise<IHandleWrapper | null>;
    /**
     * Selects all elements identified by selector on the specified web page. Function does not perform any waiting for the elements to appear.
     *
     * @param page A web page where the selected elements should be located.
     * @returns A Promise that resolves with an array of IHandleWrappers for selected elements, the array may be empty if no element is found.
     */
    selectAll(page: Page): Promise<IHandleWrapper[]>;
    toString(): string;
}
//# sourceMappingURL=types.d.ts.map