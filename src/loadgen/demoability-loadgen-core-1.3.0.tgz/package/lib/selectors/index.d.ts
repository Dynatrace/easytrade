export { ISelector } from "./types";
export { CssSelector } from "./cssSelector";
export { XpathSelector } from "./xpathSelector";
//# sourceMappingURL=index.d.ts.map