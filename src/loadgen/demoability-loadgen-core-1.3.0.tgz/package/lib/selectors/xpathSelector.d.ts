import { Page } from "puppeteer";
import { ISelector } from "./types";
import { IHandleWrapper } from "../handles";
/**
 * The class provides functionality and support for xpath selectors.
 */
export declare class XpathSelector implements ISelector {
    readonly label: string;
    readonly baseValue: string;
    readonly value: string;
    constructor(label: string, value: string);
    isPresent(page: Page): Promise<boolean>;
    select(page: Page): Promise<IHandleWrapper | null>;
    selectAll(page: Page): Promise<IHandleWrapper[]>;
    toString(): string;
    xpathSelectorString(value: string): string;
}
//# sourceMappingURL=xpathSelector.d.ts.map