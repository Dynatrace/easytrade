import { Page } from "puppeteer";
import { ISelector } from "./types";
import { IHandleWrapper } from "../handles";
/**
 * The class provides functionality and support for css selectors.
 */
export declare class CssSelector implements ISelector {
    readonly label: string;
    readonly value: string;
    constructor(label: string, value: string);
    isPresent(page: Page): Promise<boolean>;
    select(page: Page): Promise<IHandleWrapper | null>;
    selectAll(page: Page): Promise<IHandleWrapper[]>;
    toString(): string;
}
//# sourceMappingURL=cssSelector.d.ts.map