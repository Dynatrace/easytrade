export { IVisit } from "./types";
//# sourceMappingURL=index.d.ts.map