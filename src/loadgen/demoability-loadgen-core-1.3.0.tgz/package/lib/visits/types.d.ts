import { Logger } from "winston";
import { IPageActions } from "../pageActions";
/**
 * Represents a load generator visit definition
 */
export interface IVisit {
    /**
     * Execute the visit using the steps provided with pageActions
     *
     * @param pageActions
     * @param logger
     */
    run(pageActions: IPageActions, logger: Logger): Promise<void>;
    /**
     * Run a setup function before the visit will be run
     *
     * @param pageActions
     * @param logger
     */
    setup(pageActions: IPageActions, logger: Logger): Promise<void>;
    getName(): string;
}
//# sourceMappingURL=types.d.ts.map