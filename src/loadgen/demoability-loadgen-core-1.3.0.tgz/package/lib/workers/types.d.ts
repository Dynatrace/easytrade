export interface IWorker {
    run(): Promise<void>;
}
//# sourceMappingURL=types.d.ts.map