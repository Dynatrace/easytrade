import { IWorker } from "./types";
import { Logger, LoggerOptions } from "winston";
import { IProvider, ProviderItem } from "../providers";
import { IVisit } from "../visits";
import { PageActionsConfig, PageSetup } from "../pageActions";
import { IBrowserContextPool } from "../browser";
import { IStatsAggregator } from "../stats";
export declare class VisitWorker implements IWorker {
    readonly name: string;
    readonly browserContextPool: IBrowserContextPool;
    readonly logger: Logger;
    readonly initialPageSetup?: PageSetup;
    readonly pageActionsConfig: PageActionsConfig;
    readonly provider: IProvider<IVisit>;
    readonly statsReporter: IStatsAggregator;
    private isRunning;
    constructor(name: string, browserContextPool: IBrowserContextPool, loggerOptions: LoggerOptions, pageActionsConfig: PageActionsConfig, provider: IProvider<IVisit>, statsReporter: IStatsAggregator, initialPageSetup?: PageSetup);
    run(): Promise<void>;
    dispatchItem(item: ProviderItem<IVisit>): Promise<void>;
    runVisit(visit: IVisit): Promise<void>;
}
//# sourceMappingURL=visitWorker.d.ts.map