import { LoggerOptions, Logger } from "winston";
export type LoggerType = "visit" | "browser" | "stats" | "provider";
export declare function createLoggerOptions(type: LoggerType, options?: {
    logLevel?: string;
}): LoggerOptions;
export declare function addContext(logger: Logger, context: Record<string, string | undefined>): void;
//# sourceMappingURL=index.d.ts.map