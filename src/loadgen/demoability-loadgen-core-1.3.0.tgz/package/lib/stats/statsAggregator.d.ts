import { Timeframe } from "../time";
import { Entry, IStatsAggregator, TimeframeStats } from "./types";
export declare class StatsAggregator implements IStatsAggregator {
    private startTime;
    private entries;
    private stats;
    constructor(start: number);
    getStartTime(): number;
    reset(start: number): void;
    trimEntriesToTimeframe(tf: Timeframe): void;
    addEntry(entry: Entry): void;
    getGlobalStats(to: number, msPerTimeUnit: number): TimeframeStats;
    getTimeframedStats(timeframes: Timeframe[], msPerTimeUnit: number): TimeframeStats[];
}
//# sourceMappingURL=statsAggregator.d.ts.map