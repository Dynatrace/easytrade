import { LoggerOptions } from "winston";
import { IStatsAggregator } from "./types";
import { Duration, TimeUnit } from "../time";
export interface IStatsRunner {
    start(start: number): Promise<void>;
    stop(): void;
    getReporter(): IStatsAggregator;
}
export declare class StatsRunner implements IStatsRunner {
    private reportingPeriodMs;
    private trackingPeriodMs;
    private aggregator;
    private started;
    entryRateTimeUnit: TimeUnit;
    statTimeframes: Duration[];
    private logger;
    constructor(reportingPeriod: Duration, trackingPeriod: Duration, reporter: IStatsAggregator, entryRateTimeUnit: TimeUnit, statTimeframes: Duration[], loggerOptions: LoggerOptions);
    getReporter(): IStatsAggregator;
    start(start: number): Promise<void>;
    stop(): void;
    getStats(now: number): void;
}
//# sourceMappingURL=statsRunner.d.ts.map