import type { Timeframe } from "../time";
export type FailEntry = {
    name: string;
    timestamp: number;
    success: false;
};
export type SuccessEntry = {
    name: string;
    timestamp: number;
    success: true;
    durationMs: number;
};
export type Entry = SuccessEntry | FailEntry;
export type EntryStats = {
    total: number;
    avgDurationMs: number;
    failRate: number;
};
export type TimeframeStats = {
    timeframe: Timeframe;
    total: number;
    entryRate: number;
    failRate: number;
    details: Record<string, EntryStats>;
};
export interface IStatsAggregator {
    /**
     * Reset the data in the aggregator
     *
     * @param start the timestamp that will be used as a start for the aggregator
     */
    reset(start: number): void;
    /**
     * Get the start timestamp
     */
    getStartTime(): number;
    /**
     *
     * @param entry the entry that will be added to the aggregator
     */
    addEntry(entry: Entry): void;
    /**
     *
     * @param tf any entries kept internally that do not fall within this timeframe will be removed
     */
    trimEntriesToTimeframe(tf: Timeframe): void;
    /**
     *
     * @param now the timestamp that will be used as the end of data collection,
     * the timeframe between start of aggregator and now will be used to calculate entry rate
     * @param msPerTimeUnit will be used in converting the entry rate to more readable value, 1000 will give
     * entries per second, 60_000 will give entries per minute etc.
     */
    getGlobalStats(now: number, msPerTimeUnit: number): TimeframeStats;
    /**
     *
     * @param timeframes a list of timeframes for which to calculate the stats
     * @param msPerTimeUnit will be used in converting the entry rate to more readable value, 1000 will give
     * entries per second, 60_000 will give entries per minute etc.
     */
    getTimeframedStats(timeframes: Timeframe[], msPerTimeUnit: number): TimeframeStats[];
}
//# sourceMappingURL=types.d.ts.map