import { LoggerOptions } from "winston";
import { PageActionsConfig, PageSetup } from "../pageActions";
import { IProvider } from "../providers";
import { IVisit } from "../visits";
import { ILoadgenCore } from "../core";
import { IBrowserContextPool } from "../browser";
import { IStatsRunner } from "../stats";
export type CoreType = "concurrentContexts";
export type Options = {
    concurrency: number;
    visitProvider: IProvider<IVisit>;
    contextPool: IBrowserContextPool;
    statsRunner: IStatsRunner;
    coreType?: CoreType;
    loggerOptions?: LoggerOptions;
    initialPageSetup?: PageSetup;
    pageActionsConfig?: Partial<PageActionsConfig>;
};
/**
 * Return instance of a loadgen core configured according to the passed in options
 * @param options
 * @returns
 */
export declare function createLoadgen(options: Options): ILoadgenCore;
//# sourceMappingURL=index.d.ts.map