import { IProvider, ProviderItem } from "./types";
/**
 * Wrapps a provider and returns an item from it only once per interval.
 * If getItem() is called more than once in the interval it will return PROVIDER_PAUSED item instead.
 */
export declare class IntervalProviderWrapper<T = unknown> implements IProvider<T> {
    readonly baseProvider: IProvider<T>;
    readonly intervalMs: number;
    private lastAccess;
    private waitQueue;
    constructor(baseProvider: IProvider<T>, intervalMs: number);
    getItem(): ProviderItem<T>;
    waitForNext(): Promise<void>;
}
//# sourceMappingURL=intervalProvider.d.ts.map