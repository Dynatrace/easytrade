import { IProvider, ProviderItem } from "./types";
export declare class PeriodizedProviderWrapper<T> implements IProvider<T> {
    readonly providerFunction: (date: Date) => IProvider<T>;
    constructor(providerFunction: (date: Date) => IProvider<T>);
    waitForNext(): Promise<void>;
    getItem(): ProviderItem<T>;
}
//# sourceMappingURL=periodizedProvider.d.ts.map