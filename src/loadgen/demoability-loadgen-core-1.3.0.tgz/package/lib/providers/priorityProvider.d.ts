import { IProvider, ProviderItem } from "./types";
/**
 * Wrapps a list of providers, when getItem() is called it goes
 * through the list in order and calls getItem() for each provider,
 * untill it gets a ProviderItem that contains a value.
 *
 * WARNING: Not every provider is guaranteed to be called,
 * next provider in line is only called if the previous one is either
 * PAUSED or OUT OF ITEMS, this means that if you put a provider that
 * only SOMETIMES returns an item AFTER a provider that ALWAYS return an item
 * it will NEVER be called.
 */
export declare class PriorityProviderWrapper<T> implements IProvider<T> {
    readonly providers: IProvider<T>[];
    private waitForNextPromise;
    constructor(providers: IProvider<T>[]);
    waitForNext(): Promise<void>;
    getItem(): ProviderItem<T>;
}
//# sourceMappingURL=priorityProvider.d.ts.map