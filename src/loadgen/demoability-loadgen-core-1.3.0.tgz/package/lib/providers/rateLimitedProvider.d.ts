import { IProvider, ProviderItem } from "./types";
import { LoggerOptions } from "winston";
import { Duration } from "../time";
export declare class RateLimitedProviderWrapper<T> implements IProvider<T> {
    readonly baseProvider: IProvider<T>;
    readonly timeframeMs: number;
    readonly fractionOfBase: (now: Date) => number | undefined;
    readonly initialTfDelay: number;
    private countForTimeframe;
    private startOfTimeframe;
    private currentTimeframeCount;
    private isFirstPeriod;
    private lastItemProvidedTime;
    private baseDelay;
    private waitQueue;
    private logger;
    constructor(baseProvider: IProvider<T>, timeframeDuration: Duration, fractionOfBase: (now: Date) => number | undefined, initialTfDelay: number, loggerOptions: LoggerOptions);
    getItem(): ProviderItem<T>;
    getFraction(): number;
    getDelayToNext(): number;
    waitForNext(): Promise<void>;
}
//# sourceMappingURL=rateLimitedProvider.d.ts.map