export type Item<T> = {
    type: "item";
    value: T;
};
export type ProviderPaused = {
    type: "paused";
};
export type OutOfItems = {
    type: "outOfItems";
};
export type ProviderItem<T> = Item<T> | ProviderPaused | OutOfItems;
export interface IProvider<T = unknown> {
    getItem(): ProviderItem<T>;
    waitForNext(): Promise<void>;
}
//# sourceMappingURL=types.d.ts.map