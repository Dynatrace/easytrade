import { IProvider, ProviderItem } from "./types";
/**
 * Similar to PriorityProviderWrapper, but after every getItem()
 * call, it changes the order of providers so with N providers in list
 * after N getItem() calls, every provider is guaranteed to have been called
 *
 */
export declare class MultiProviderWrapper<T> implements IProvider<T> {
    readonly providers: IProvider<T>[];
    private waitForNextPromise;
    constructor(providers: IProvider<T>[]);
    getItem(): ProviderItem<T>;
    private _getItem;
    waitForNext(): Promise<void>;
}
//# sourceMappingURL=multiProvider.d.ts.map