import { IProvider, ProviderItem } from "./types";
/**
 * Wrapps a function that provides item values
 */
export declare class FunctionProviderWrapper<T> implements IProvider<T> {
    readonly providerFunction: () => T;
    constructor(providerFunction: () => T);
    getItem(): ProviderItem<T>;
    waitForNext(): Promise<void>;
}
//# sourceMappingURL=functionProvider.d.ts.map