import { Item } from "./types";
export { Item, OutOfItems, ProviderPaused, ProviderItem, IProvider, } from "./types";
export { OUT_OUF_ITEMS, PROVIDER_PAUSED } from "./const";
export { IntervalProviderWrapper } from "./intervalProvider";
export { PriorityProviderWrapper } from "./priorityProvider";
export { MultiProviderWrapper } from "./multiProvider";
export { FunctionProviderWrapper } from "./functionProvider";
export { LimitedPorviderWrapper } from "./limitedProvider";
export { WeightedProvider } from "./weightedProvider";
export { PeriodizedProviderWrapper } from "./periodizedProvider";
export { RateLimitedProviderWrapper } from "./rateLimitedProvider";
export declare function wrapItem<T>(item: T): Item<T>;
//# sourceMappingURL=index.d.ts.map