import { IProvider, ProviderItem } from "./types";
/**
 * Takes in a function that produces items and weight distribution for those items,
 * the weights will be scaled such that the smallest weight is set to 1.
 *
 * Provider works in cycles, for each cycle it will return the amount of an item
 * given by it's normalized weight. This guarantees consistent output of items
 * but the distribution may not exactly match the original weights.
 *
 * Setting the weight to <= 0 will skip the item entirely.
 *
 */
export declare class WeightedProvider<T, K extends Record<string, number>> implements IProvider<T> {
    readonly itemWeights: Record<string, number>;
    readonly itemProvider: (name: keyof K) => T;
    private internalProvider;
    constructor(itemWeights: K, itemProvider: (name: keyof K) => T);
    waitForNext(): Promise<void>;
    getItem(): ProviderItem<T>;
    /**
     * Normalize weights in such a way that the smalles weight is scaled to 1,
     * all other weights are scaled accordingly and rounded.
     * This means that the result may not exactly follow the initial distribution of weights.
     *
     * Weights thate are not bigger than 0 will be dropped.
     *
     * @param weights
     * @returns
     */
    private normalizeWeights;
    private getInternalProvider;
    private getProviderForItem;
}
//# sourceMappingURL=weightedProvider.d.ts.map