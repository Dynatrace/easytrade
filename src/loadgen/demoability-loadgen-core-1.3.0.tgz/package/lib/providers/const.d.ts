import { OutOfItems, ProviderPaused } from "./types";
export declare const OUT_OUF_ITEMS: OutOfItems;
export declare const PROVIDER_PAUSED: ProviderPaused;
//# sourceMappingURL=const.d.ts.map