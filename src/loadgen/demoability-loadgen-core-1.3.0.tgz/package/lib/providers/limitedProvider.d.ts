import { IProvider, ProviderItem } from "./types";
/**
 * Wrapps a provider and then only provides the given amount of items
 * from that provider. Once the limit is reached returns OUT_OF_ITEMS
 *
 */
export declare class LimitedPorviderWrapper<T> implements IProvider<T> {
    readonly baseProvider: IProvider<T>;
    readonly limit: number;
    private counter;
    constructor(baseProvider: IProvider<T>, limit: number);
    waitForNext(): Promise<void>;
    getItem(): ProviderItem<T>;
}
//# sourceMappingURL=limitedProvider.d.ts.map