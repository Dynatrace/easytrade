export declare class EnvConfig {
    private static throwForEnv;
    static ensureString(name: string, defaultValue?: string): string;
    static optionalString(name: string): string | undefined;
    static ensureNumber(name: string, defaultValue?: number): number;
    static optionalNumber(name: string, config?: {
        acceptInvalid?: boolean;
    } | undefined): number | undefined;
    static ensureEnum<T extends string>(name: string, values: readonly T[], defaultValue?: T): T;
    static optionalEnum<T extends string>(name: string, values: readonly T[], config?: {
        acceptInvalid?: boolean;
    } | undefined): T | undefined;
    static ensureUrl(name: string, defaultValue?: URL): URL;
    static optionalUrl(name: string, config?: {
        acceptInvalid?: boolean;
    } | undefined): URL | undefined;
}
//# sourceMappingURL=index.d.ts.map