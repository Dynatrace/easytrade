# Loadgen CORE

## About

`loadge-core` provides versatile library to generate load on a website, [**Puppeteer**](https://pptr.dev) library is used to provide RUM data.

## Usage

Check the `./examples` folder for the example use of the loadgen

## Publishing

To publish new versions of the library to [Artifact Registry](https://console.cloud.google.com/artifacts/npm/dynatrace-demoability/europe/npm/@demoability%2Floadgen-core?project=dynatrace-demoability) you need to configure the npm to know about the registry following the [docs](https://cloud.google.com/artifact-registry/docs/nodejs/authentication), you can use your user or the [service-account](https://secretserver.dynatrace.org/app/#/secrets/22562/general).

> NOTE: this should be one time setup

**Now all you need to do is to make sure you update the package version in `package.json` file and then run**

```bash
# run tests to make sure their passing
npm run test:build

npm publish

# to check the contents of the deployed artifact
npm pack --dry-run
```

## Technology

- Puppeteer
- Typescript

## Automation

There is a pipeline in jenkins that takes care of building and publishing the new library version to GAR (Google Artifact Registry): https://cluster-jenkins.ci.dynalabs.io/job/DemoApps/job/loadgen-core/job/master/

The pipeline updates the version found in package.json by adding an extra ".X" to it, where X is the jenkins build number. **This change is not persisted.**

After building a new version if you want it to be used in easyTrade, then you have to update the package.json file in loadgen project.
